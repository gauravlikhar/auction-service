/**
 * @author yukti.gupta
 * @date 28/04/23
 * @project_name auction
 **/

package com.assignment.auction.constants;

public class RedisConstants {

    public static final int REDIS_LOCK_TIMEOUT_COUNT = 5;
}
