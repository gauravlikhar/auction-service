package com.assignment.auction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
